import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";

import Home from "./Routes/Home";
import Header from "./Components/Header";
import PokeInfo from "./Routes/PokeInfo";

const HomeAdapter = ({ history, location }) => (
  <Home history={history} location={location} />
);

const Routes = () => (
  <Router>
    <div>
      <Header />
      <Route path="/" component={HomeAdapter} exact />
      <Route
        path="/:name"
        render={props => <PokeInfo url={props.location.state.url} />}
        exact
      />
    </div>
  </Router>
);

export default Routes;

import React, { Component } from "react";
import PokemonNameCard from "../Components/PokemonNameCard";
import ReactPaginate from "react-paginate";

import "./Home.css";

const pokeMockup = [
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" },
  { name: "Bulbassaur" }
];

export default class Home extends Component {
  constructor(props) {
    super(props);

    this.state = {
      pokemonsList: [],
      limit: 12,
      paginatedList: [],
      pageCount: null
    };
  }

  componentDidMount() {
    this.fetchPokemonList();
  }

  fetchPokemonList = () => {
    fetch("https://pokeapi.co/api/v2/pokemon/", { method: "GET" })
      .then(response => response.json())
      .then(responseJson => {
        const { results } = responseJson;
        const { offset, limit } = this.state;
        this.setState({
          pokemonsList: results,
          pageCount: results.length / 12,
          paginatedList: results.slice(offset, limit)
        });
      });
  };

  handlePageClick = currentPage => {
    const { limit, pokemonsList } = this.state;
    const initialOffset = currentPage.selected * limit;

    this.setState({
      paginatedList: pokemonsList.slice(initialOffset, initialOffset + limit)
    });
  };

  handleSelectPokemon = (url, name) => {
    this.props.history.push(`${name}`, { url });
  };

  render() {
    return (
      <div>
        <div className="container">
          {this.state.paginatedList.map((pokemon, idx) => (
            <PokemonNameCard
              pokemonName={pokemon.name}
              onPress={() =>
                this.handleSelectPokemon(pokemon.url, pokemon.name)
              }
              key={idx}
            />
          ))}
        </div>
        {this.state.pokemonsList.length > 0 && (
          <div className="paginationContainer">
            <ReactPaginate
              previousLabel={"Previous"}
              nextLabel={"Next"}
              breakLabel={"..."}
              breakClassName={"break-me"}
              pageCount={this.state.pageCount}
              marginPagesDisplayed={2}
              pageRangeDisplayed={5}
              onPageChange={this.handlePageClick}
              containerClassName={"pagination"}
              activeClassName={"active"}
              pageClassName={"page"}
              previousLinkClassName={"previous"}
              nextLinkClassName={"next"}
              subContainerClassName={"subcontainer"}
            />
          </div>
        )}
      </div>
    );
  }
}

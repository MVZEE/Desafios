import React, { Component } from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";

const styles = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2
  }
});

class PokeInfo extends Component {
  constructor(props) {
    super(props);

    this.state = {
      name: "",
      baseExp: "",
      height: "",
      weight: ""
    };
  }

  fetchPokemonData = () => {
    const { url } = this.props;
    fetch(url, { method: "GET" })
      .then(response => response.json())
      .then(responseJson =>
        this.setState({
          name: responseJson.name,
          baseExp: responseJson.base_experience,
          height: responseJson.height,
          weight: responseJson.weight
        })
      );
  };

  componentDidMount() {
    this.fetchPokemonData();
  }

  render() {
    const { name, baseExp, height, weight } = this.state;
    return (
      <div>
        <Paper className={this.props.classes.root} elevation={1}>
          <Typography variant="h3">Pokémon Informations</Typography>
          <Typography variant="h4">Name</Typography>
          <Typography variant="h5">{name}</Typography>
          <Typography variant="h4">Height</Typography>
          <Typography variant="h5">{height}</Typography>
          <Typography variant="h4">Weight</Typography>
          <Typography variant="h5">{weight}</Typography>
          <Typography variant="h4">Base Experience</Typography>
          <Typography variant="h5">{baseExp}</Typography>
        </Paper>
      </div>
    );
  }
}

PokeInfo.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(PokeInfo);

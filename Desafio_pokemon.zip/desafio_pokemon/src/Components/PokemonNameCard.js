import React, { Component } from "react";
import { withStyles } from "@material-ui/core/styles";
import PropTypes from "prop-types";
import Card from "@material-ui/core/Card";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";

const styles = {
  card: {
    width: 300,
    marginLeft: 8,
    marginRight: 8,
    marginBottom: 10,
    marginTop: 10
  },
  title: {
    fontSize: 14
  }
};

class PokemonNameCard extends Component {
  render() {
    const { classes, pokemonName, onPress } = this.props;
    return (
      <Card className={classes.card}>
        <CardContent>
          <Typography
            className={classes.title}
            color="textSecondary"
            gutterBottom
          >
            Pokémon Name
          </Typography>
          <Typography variant="h5" component="h2">
            {pokemonName}
          </Typography>
        </CardContent>
        <CardActions>
          <Button onClick={onPress} size="small">
            View Details
          </Button>
        </CardActions>
      </Card>
    );
  }
}

PokemonNameCard.propTypes = {
  classes: PropTypes.object.isRequired,
  pokemonName: PropTypes.string.isRequired,
  onPress: PropTypes.func.isRequired
};

export default withStyles(styles)(PokemonNameCard);

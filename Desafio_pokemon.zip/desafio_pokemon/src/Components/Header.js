import React from "react";

import Typography from "@material-ui/core/Typography";

import "./Header.css";

export default class Header extends React.Component {
  render() {
    return (
      <div className="header">
        <Typography variant="h2" color="primary">
          Pokémons List
        </Typography>
      </div>
    );
  }
}
